# 1 - `Setup le bot`

** **
- Ouvrez le fichier .env
- Mettez le token du bot et l'id de l'owner
- lancez le bot
** **
- Ouvrez le fichier .env
![image](https://user-images.githubusercontent.com/99873347/170371348-6e2ae044-9566-4cfe-8614-d8470ad4577b.png)

- Remplissez les informations
![image](https://user-images.githubusercontent.com/99873347/170371508-40bf5260-12a3-43b3-883a-795adae36dc6.png)

- Lancez le bot
![image](https://user-images.githubusercontent.com/99873347/170372138-aa6b0e98-d0ac-4ef2-8605-315317d996d6.png)


# 2 - `Création du token d'un bot`

- Vous devez vous rendre sur le [Discord Developer Portal](https://discord.com/developers/applications)
- Ensuite créé une application
 ![image](https://user-images.githubusercontent.com/99873347/170369991-17ba51df-fe3b-4ef5-a0fa-96c8a30a1562.png)
 
- Choisissez le nom de votre bot
 ![image](https://user-images.githubusercontent.com/99873347/170370151-911c269a-7f81-414e-986d-1b3cfe8b93c7.png)

- Allez dans la section **Bot**
![image](https://user-images.githubusercontent.com/99873347/170370697-324aaa85-3afb-421d-9c74-519abf1f6599.png)

- Créé un bot
![image](https://user-images.githubusercontent.com/99873347/170370752-b6be326f-4222-4417-b839-28b1583515e6.png)

- Activez les intents (descendez)
![image](https://user-images.githubusercontent.com/99873347/170370892-4a7bf44f-fc49-4c22-83eb-620aff898569.png)

- Réintialise le token
![image](https://user-images.githubusercontent.com/99873347/170370969-d30180df-2fc2-4cc1-8198-a744cf933bcd.png)

- Vous avez le token de votre bot
![image](https://user-images.githubusercontent.com/99873347/170371050-be22c746-4e1a-4e83-9e07-b325cbac3812.png)
